export { addIcons } from './components/icon/utils';
export type { Components, JSX } from './components';
